<h1 align="center">🚀 LoveTool V3 🚀</h1>
<em><h5 align="center">(Language: Python, Shell)</h5></em>
  
<p align="center">Vui lòng không tấn công các trang web liên quan tới chính phủ.</p>

<p align="center"><img src="https://i.imgur.com/ZFPU2zj.png" width="800" height="500" alt="Demo DDoS"></p>

# Mothed

* Layer7 
* Layer4 

# Cách Vào Tool

* Vào CH Play Hoặc Appstore Tải Google Cloud Để Chạy Tool Nhé!

* ```git clone https://github.com/VH006/LoveToolV3```
* ```cd LoveToolV3```
* ```unzip ddos.zip```
* ```Nhập Pass Vào, Pass Lấy Tại: http://traffic1s.com/Pass```
* ```sh install.sh```
# Video Hướng Dẫn
* t.me/+-8EFBSxln4Y2ZWY1
# Contact Me 
* Telegram: @viduchung06
* Zalo: 0359822840
* Facebook: @Viduchung.06

# Donate 
* Momo: 0359822840 <br>
CTK: Vi Đức Hùng 
* Tsr: 0359822840 <br>
CTK: Vi Hùng
* SHB: 0000190506 <br>
CTK: VI DUC HUNG 

# Developers
* Vi Duc Hung X NguyenPhat X FDc0d3

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/VH006/LoveToolV3hit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)



